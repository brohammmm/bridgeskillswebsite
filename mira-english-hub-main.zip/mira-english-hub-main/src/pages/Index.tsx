import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import SocialProof from "@/components/SocialProof";
import About from "@/components/About";
import Courses from "@/components/Courses";
import Transformation from "@/components/Transformation";
import CTASection from "@/components/CTASection";
import LocationSection from "@/components/LocationSection";
import FAQSection from "@/components/FAQSection";
import Footer from "@/components/Footer";
import FloatingButtons from "@/components/FloatingButtons";

const Index = () => (
  <div className="min-h-screen pb-12 md:pb-0">
    <Navbar />
    <Hero />
    <div id="reviews"><SocialProof /></div>
    <div id="about"><About /></div>
    <div id="courses"><Courses /></div>
    <Transformation />
    <CTASection />
    <LocationSection />
    <div id="faq"><FAQSection /></div>
    <Footer />
    <FloatingButtons />
  </div>
);

export default Index;
