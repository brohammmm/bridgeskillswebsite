import { motion } from "framer-motion";
import { Star } from "lucide-react";

const testimonials = [
  { name: "Santosh Pradhan", text: "Sushma mam helped me understand that good public speaking isn't about being perfect — it's about being authentic and connecting with your audience. She encouraged me to add my own personality to speeches." },
  { name: "Vanitha Suresh", text: "Sushma Ma'am is an outstanding teacher. Her exceptional teaching skills, coupled with her ability to simplify complex concepts, have greatly enhanced understanding and appreciation of the subject." },
  { name: "Thwishaa Sharma", text: "This training helped me improve my public speaking skills drastically. I learnt how to speak confidently and also learnt new techniques to improve my skills. Sushma mam is the best!" },
  { name: "Student", text: "I would highly recommend everyone who is looking for spoken English class. I got visible results in merely 5-6 sessions. The instructor taught me in an interesting manner." },
];

const SocialProof = () => (
  <section className="py-16 md:py-24 bg-background">
    <div className="container">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-12"
      >
        <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-3">
          What Our Students Say
        </h2>
        <p className="text-muted-foreground text-lg">Real results from real students</p>
      </motion.div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {testimonials.map((t, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="bg-card rounded-lg p-6 card-shadow hover:card-shadow-hover transition-shadow"
          >
            <div className="flex gap-0.5 mb-3">
              {Array.from({ length: 5 }).map((_, j) => (
                <Star key={j} className="h-4 w-4 text-accent fill-accent" />
              ))}
            </div>
            <p className="text-card-foreground/80 mb-4 text-sm leading-relaxed">"{t.text}"</p>
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold text-sm">
                {t.name[0]}
              </div>
              <span className="font-medium text-card-foreground text-sm">{t.name}</span>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default SocialProof;
