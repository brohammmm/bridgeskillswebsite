import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { motion } from "framer-motion";

const faqs = [
  { q: "What programs do you offer?", a: "We offer Spoken English, Public Speaking, Communication Training, and Hindi language classes. Our programs are designed for students, professionals, and anyone looking to improve their language and communication skills." },
  { q: "How quickly will I see results?", a: "Many students see visible improvement in just 5-6 sessions! Our practical, hands-on approach ensures you start speaking more confidently from day one." },
  { q: "Is this suitable for beginners?", a: "Absolutely! We welcome learners at all levels — from complete beginners to those looking to polish their existing skills. Our teaching is patient, structured, and personalized." },
  { q: "Do you offer flexible timings?", a: "Yes! We have batches available at convenient hours for students and working professionals. We're open daily until 7 PM." },
  { q: "Do you offer online classes?", a: "Please contact us directly to discuss online class availability. We're happy to work out a schedule that suits your needs." },
];

const FAQSection = () => (
  <section className="py-16 md:py-24 bg-secondary">
    <div className="container">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-12"
      >
        <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-3">Frequently Asked Questions</h2>
      </motion.div>

      <div className="max-w-2xl mx-auto">
        <Accordion type="single" collapsible className="space-y-3">
          {faqs.map((faq, i) => (
            <AccordionItem key={i} value={`faq-${i}`} className="bg-card rounded-lg px-6 card-shadow border-none">
              <AccordionTrigger className="text-left font-semibold text-card-foreground hover:no-underline">
                {faq.q}
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground leading-relaxed">
                {faq.a}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </div>
  </section>
);

export default FAQSection;
