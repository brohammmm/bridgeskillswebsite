import { Phone, MessageCircle, MapPin, Instagram, Facebook, Youtube } from "lucide-react";

const Footer = () => (
  <footer className="bg-foreground py-12">
    <div className="container">
      <div className="grid md:grid-cols-3 gap-8 text-primary-foreground/80">
        <div>
          <h3 className="text-xl font-bold text-primary-foreground mb-3">Bridgeskillz</h3>
          <p className="text-sm leading-relaxed">English language school in Bengaluru. Expert training in Spoken English, Public Speaking & Communication to help you express yourself with confidence.</p>
        </div>
        <div>
          <h4 className="font-semibold text-primary-foreground mb-3">Contact</h4>
          <div className="space-y-2 text-sm">
            <a href="tel:+919731999661" className="flex items-center gap-2 hover:text-primary-foreground transition-colors">
              <Phone className="h-4 w-4" /> 097319 99661
            </a>
            <a href="https://wa.me/919731999661" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:text-primary-foreground transition-colors">
              <MessageCircle className="h-4 w-4" /> WhatsApp Us
            </a>
            <div className="flex items-start gap-2">
              <MapPin className="h-4 w-4 mt-0.5 shrink-0" />
              <span>Tower 2, Adarsh Palm Retreat Villas, Bellandur, Bengaluru 560103</span>
            </div>
          </div>
        </div>
        <div>
          <h4 className="font-semibold text-primary-foreground mb-3">Follow Us</h4>
          <div className="flex gap-3">
            <a href="#" className="w-9 h-9 rounded-full bg-primary-foreground/10 flex items-center justify-center hover:bg-primary-foreground/20 transition-colors">
              <Instagram className="h-4 w-4" />
            </a>
            <a href="#" className="w-9 h-9 rounded-full bg-primary-foreground/10 flex items-center justify-center hover:bg-primary-foreground/20 transition-colors">
              <Facebook className="h-4 w-4" />
            </a>
            <a href="#" className="w-9 h-9 rounded-full bg-primary-foreground/10 flex items-center justify-center hover:bg-primary-foreground/20 transition-colors">
              <Youtube className="h-4 w-4" />
            </a>
          </div>
        </div>
      </div>
      <div className="border-t border-primary-foreground/10 mt-8 pt-6 text-center text-primary-foreground/50 text-sm">
        © {new Date().getFullYear()} Bridgeskillz. All rights reserved.
      </div>
    </div>
  </footer>
);

export default Footer;
