import { motion } from "framer-motion";
import { MessageCircle as MessageIcon, Mic, Users } from "lucide-react";
import { Button } from "@/components/ui/button";

const courses = [
  {
    icon: MessageIcon,
    title: "Spoken English",
    items: ["Fluency & pronunciation training", "Grammar & vocabulary building", "Visible results in 5-6 sessions"],
    color: "primary" as const,
  },
  {
    icon: Mic,
    title: "Public Speaking",
    items: ["Confidence & stage presence", "Speech structuring techniques", "Authentic communication skills"],
    color: "accent" as const,
  },
  {
    icon: Users,
    title: "Communication Training",
    items: ["Professional communication skills", "Interview & presentation prep", "Group discussions & debates"],
    color: "primary" as const,
  },
];

const Courses = () => (
  <section className="py-16 md:py-24 bg-background">
    <div className="container">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-12"
      >
        <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-3">Our Programs</h2>
        <p className="text-muted-foreground text-lg">Choose the program that fits your goals</p>
      </motion.div>

      <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
        {courses.map((c, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.15 }}
            className="bg-card rounded-lg p-6 card-shadow hover:card-shadow-hover transition-shadow flex flex-col"
          >
            <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-4 ${c.color === "accent" ? "bg-accent/10" : "bg-primary/10"}`}>
              <c.icon className={`h-6 w-6 ${c.color === "accent" ? "text-accent" : "text-primary"}`} />
            </div>
            <h3 className="text-xl font-bold text-card-foreground mb-4">{c.title}</h3>
            <ul className="space-y-2 mb-6 flex-1">
              {c.items.map((item, j) => (
                <li key={j} className="flex items-start gap-2 text-muted-foreground text-sm">
                  <span className="text-accent mt-1">✓</span>
                  {item}
                </li>
              ))}
            </ul>
            <Button
              className="w-full bg-accent-gradient text-accent-foreground hover:opacity-90"
              onClick={() => window.open("https://wa.me/919731999661?text=Hi!%20I'm%20interested%20in%20" + encodeURIComponent(c.title) + "%20training%20at%20Bridgeskillz", "_blank")}
            >
              Enquire Now
            </Button>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default Courses;
