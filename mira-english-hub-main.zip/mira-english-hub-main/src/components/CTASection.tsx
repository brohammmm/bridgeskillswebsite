import { motion } from "framer-motion";
import { Phone, MessageCircle, CalendarCheck } from "lucide-react";
import { Button } from "@/components/ui/button";

const CTASection = () => (
  <section className="py-16 md:py-24 bg-hero-gradient relative overflow-hidden">
    <div className="absolute inset-0 opacity-10">
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary-foreground rounded-full blur-3xl" />
    </div>
    <div className="container relative z-10">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center max-w-2xl mx-auto"
      >
        <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-4">
          Ready to Speak with Confidence?
        </h2>
        <p className="text-primary-foreground/80 text-lg mb-8">
          Take the first step today. Book a free session and experience the difference at Bridgeskillz.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            size="lg"
            className="bg-accent-gradient text-accent-foreground hover:opacity-90 text-lg px-8 py-6 font-semibold"
            onClick={() => window.open("tel:+919731999661")}
          >
            <CalendarCheck className="mr-2 h-5 w-5" />
            Book Free Session
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="bg-sidebar-ring border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 text-lg px-6 py-6"
            onClick={() => window.open("tel:+919731999661")}
          >
            <Phone className="mr-2 h-5 w-5" />
            Call Now
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="bg-sidebar-ring border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 text-lg px-6 py-6"
            onClick={() => window.open("https://wa.me/919731999661", "_blank")}
          >
            <MessageCircle className="mr-2 h-5 w-5" />
            WhatsApp Now
          </Button>
        </div>
      </motion.div>
    </div>
  </section>
);

export default CTASection;
