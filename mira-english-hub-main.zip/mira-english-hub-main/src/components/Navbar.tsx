import { useState } from "react";
import { Menu, X, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";

const Navbar = () => {
  const [open, setOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-40 bg-card/95 backdrop-blur-md border-b border-border">
      <div className="container flex items-center justify-between h-16">
        <a href="/" className="font-heading text-xl font-bold text-primary">
          Bridgeskillz
        </a>

        <div className="hidden md:flex items-center gap-6 text-sm font-medium text-muted-foreground">
          <a href="#courses" className="hover:text-foreground transition-colors">Programs</a>
          <a href="#about" className="hover:text-foreground transition-colors">About</a>
          <a href="#reviews" className="hover:text-foreground transition-colors">Reviews</a>
          <a href="#faq" className="hover:text-foreground transition-colors">FAQ</a>
          <Button size="sm" className="bg-accent-gradient text-accent-foreground hover:opacity-90" onClick={() => window.open("tel:+919731999661")}>
            <Phone className="mr-1.5 h-4 w-4" /> Call Now
          </Button>
        </div>

        <button className="md:hidden" onClick={() => setOpen(!open)}>
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {open && (
        <div className="md:hidden border-t border-border bg-card px-6 py-4 space-y-3">
          <a href="#courses" className="block text-sm text-muted-foreground hover:text-foreground" onClick={() => setOpen(false)}>Programs</a>
          <a href="#about" className="block text-sm text-muted-foreground hover:text-foreground" onClick={() => setOpen(false)}>About</a>
          <a href="#reviews" className="block text-sm text-muted-foreground hover:text-foreground" onClick={() => setOpen(false)}>Reviews</a>
          <a href="#faq" className="block text-sm text-muted-foreground hover:text-foreground" onClick={() => setOpen(false)}>FAQ</a>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
