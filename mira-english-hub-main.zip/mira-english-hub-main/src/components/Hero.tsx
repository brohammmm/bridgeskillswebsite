import { motion } from "framer-motion";
import { Phone, MessageCircle, Star, MapPin, Award } from "lucide-react";
import { Button } from "@/components/ui/button";

const Hero = () => {
  return (
    <section className="relative overflow-hidden bg-hero-gradient py-20 md:py-28">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-72 h-72 bg-primary-foreground rounded-full blur-3xl" />
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-primary-foreground rounded-full blur-3xl" />
      </div>

      <div className="container relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-block mb-4 px-4 py-1.5 rounded-full bg-primary-foreground/20 text-primary-foreground text-sm font-medium">
              🔥 New Batches Starting Soon — Enroll Now!
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-primary-foreground leading-tight mb-4">
              Bridgeskillz
            </h1>
            <p className="text-lg md:text-xl text-primary-foreground/80 mb-8 max-w-2xl mx-auto">
              Spoken English & Communication Training in Bengaluru — Build Confidence, Public Speaking & Language Skills
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex flex-col sm:flex-row gap-4 justify-center mb-10"
          >
            <Button
              size="lg"
              className="bg-accent-gradient text-accent-foreground hover:opacity-90 text-lg px-8 py-6 font-semibold shadow-lg"
              onClick={() => window.open("tel:+919731999661")}
            >
              <Phone className="mr-2 h-5 w-5" />
              Book Free Session
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 text-lg px-8 py-6 font-semibold bg-sidebar-ring"
              onClick={() => window.open("https://wa.me/919731999661?text=Hi!%20I'm%20interested%20in%20English%20classes%20at%20Bridgeskillz", "_blank")}
            >
              <MessageCircle className="mr-2 h-5 w-5" />
              WhatsApp Us
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex flex-wrap justify-center gap-4 md:gap-8 text-primary-foreground/90 text-sm"
          >
            <div className="flex items-center gap-1.5">
              <Star className="h-4 w-4 text-accent fill-accent" />
              <span className="font-medium">4.8 Rating | 53 Reviews</span>
            </div>
            <div className="flex items-center gap-1.5">
              <MapPin className="h-4 w-4" />
              <span>Bellandur, Bengaluru</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Award className="h-4 w-4" />
              <span>Women-Owned</span>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
