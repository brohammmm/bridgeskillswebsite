import { motion } from "framer-motion";
import { User, Heart, Clock, BookOpen, Target } from "lucide-react";

const points = [
  { icon: User, title: "Expert Instructor", desc: "Sushma Ma'am brings patient, engaging teaching that makes even complex language concepts easy to grasp and master." },
  { icon: Heart, title: "Supportive Environment", desc: "A warm, encouraging atmosphere where every student feels comfortable practicing speaking and learning at their pace." },
  { icon: Target, title: "Practical Focus", desc: "Strong emphasis on real-world communication — public speaking, confidence building, and everyday English fluency." },
  { icon: Clock, title: "Flexible Timings", desc: "Convenient batch timings for students and working professionals. Open daily until 7 PM." },
  { icon: BookOpen, title: "Personalized Training", desc: "Small batches with individual attention, regular practice sessions, and personalized feedback to track your progress." },
];

const About = () => (
  <section className="py-16 md:py-24 bg-secondary">
    <div className="container">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-12"
      >
        <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-3">
          Why Choose <span className="text-primary">Bridgeskillz</span>?
        </h2>
        <p className="text-muted-foreground text-lg max-w-xl mx-auto">
          A satisfied student is our greatest asset.
        </p>
      </motion.div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
        {points.map((p, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="bg-card rounded-lg p-6 card-shadow"
          >
            <div className="w-11 h-11 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
              <p.icon className="h-5 w-5 text-primary" />
            </div>
            <h3 className="font-semibold text-card-foreground mb-2">{p.title}</h3>
            <p className="text-muted-foreground text-sm leading-relaxed">{p.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default About;
