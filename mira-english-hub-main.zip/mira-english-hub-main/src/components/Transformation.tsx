import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

const before = ["Hesitant to speak in public", "Low confidence in communication", "Struggling with English fluency"];
const after = ["Confident & authentic speaker", "Strong communication & presentation skills", "Fluent English with clear expression"];

const Transformation = () => (
  <section className="py-16 md:py-24 bg-secondary">
    <div className="container">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-12"
      >
        <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-3">
          Your <span className="text-primary">Transformation</span> Journey
        </h2>
        <p className="text-muted-foreground text-lg">See the difference our training makes</p>
      </motion.div>

      <div className="max-w-3xl mx-auto flex flex-col md:flex-row items-center gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="flex-1 w-full bg-card rounded-lg p-8 card-shadow border-l-4 border-destructive"
        >
          <h3 className="font-bold text-lg text-destructive mb-4">Before</h3>
          <ul className="space-y-3">
            {before.map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-muted-foreground">
                <span className="text-destructive">✗</span> {item}
              </li>
            ))}
          </ul>
        </motion.div>

        <div className="hidden md:flex">
          <ArrowRight className="h-8 w-8 text-primary" />
        </div>
        <div className="md:hidden">
          <ArrowRight className="h-8 w-8 text-primary rotate-90" />
        </div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="flex-1 w-full bg-card rounded-lg p-8 card-shadow border-l-4 border-primary"
        >
          <h3 className="font-bold text-lg text-primary mb-4">After</h3>
          <ul className="space-y-3">
            {after.map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-foreground">
                <span className="text-primary">✓</span> {item}
              </li>
            ))}
          </ul>
        </motion.div>
      </div>
    </div>
  </section>
);

export default Transformation;
