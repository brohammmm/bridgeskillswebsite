import { MessageCircle, Phone } from "lucide-react";

const FloatingButtons = () => (
  <>
    <a
      href="https://wa.me/919731999661?text=Hi!%20I'm%20interested%20in%20English%20classes%20at%20Bridgeskillz"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-20 right-4 md:bottom-6 md:right-6 z-50 w-14 h-14 rounded-full bg-[#25D366] flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle className="h-6 w-6 text-primary-foreground" />
    </a>

    <a
      href="tel:+919731999661"
      className="fixed bottom-0 left-0 right-0 z-50 md:hidden bg-hero-gradient text-primary-foreground py-3 flex items-center justify-center gap-2 font-semibold shadow-lg"
    >
      <Phone className="h-5 w-5" />
      Call Now — Book Free Session
    </a>
  </>
);

export default FloatingButtons;
